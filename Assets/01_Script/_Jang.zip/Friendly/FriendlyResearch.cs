﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FriendlyResearch : Friendly {

	Friendly healTarget;

	private void Start()
	{
		FriendType = FRIEND_TYPE.Resercher;	
	}
	private void FixedUpdate()
	{
		
	}
	//해당 캐릭터 정보 가져오기 위한
	public override Friendly GetFriend()
	{
		return this;
	}
	private void OnTriggerStay(Collider other)
	{
		if(other.CompareTag("Friendly"))
		{
			
		}
	}




}
