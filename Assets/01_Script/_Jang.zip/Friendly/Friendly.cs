﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;


public enum FriendlyState
{
	Idle,
	Run,
	Attack,
}
public class Friendly : MonoBehaviour
{
	public FRIEND_TYPE FriendType;

	public FriendlyGroup GroupConductor;
	public EnemyGroup targetEnemyGroup;
	public Enemy targetEnemy;
	public Transform NavObj;
	public Transform RegenPoint;
	public int DamageStack;


	public int RoomIndex;
	public int Hp;
	public float Distance;
	public float StopDistance;

	public bool isHit;

	protected Animator anime;
	protected NavMeshAgent friendAi;
	protected SphereCollider collider;
	protected Transform orderTarget;
	protected Vector3 dest;
	protected Vector3 start;

	protected FriendlyState currentState;
	protected FriendlyState setState;

	
	
	private void Awake()
	{
		anime = GetComponent<Animator>();
		friendAi = GetComponentInParent<NavMeshAgent>();
		collider = GetComponent<SphereCollider>();
		NavObj = friendAi.transform;		
	}
	private void OnEnable()
	{
		if (Hp <= 0)
			Hp = 5;

		StartCoroutine(AnimEvent());
	}
	protected bool OrderFindEnemy()
	{
		if (targetEnemyGroup != null)
		{
			if (targetEnemy == null)
				targetEnemy = targetEnemyGroup.FindEnemy();
		}
		else if (targetEnemyGroup == null)
		{

		}
		else return false;
	}

	public void ChangeEnemyTarget(Enemy enemy)
	{
		if (enemy == targetEnemy)
			return;

		targetEnemy = enemy;
	}
	//애니메이션 관리
	protected IEnumerator AnimEvent()
	{
		while (gameObject.activeSelf)
		{
			if (currentState != setState)
			{
				currentState = setState;
				anime.SetInteger("Action", (int)currentState);
				yield return null;
			}
			else
				yield return new WaitForEndOfFrame();
		}
	}
	IEnumerator DieEvent()
	{
		anime.SetInteger("Action", 0);
		anime.SetTrigger("Die");

		collider.enabled = false;
		friendAi.enabled = false;

		yield return new WaitForSeconds(1.0f);

		NavObj.gameObject.SetActive(false);
		PoolManager.current.PushFriend(NavObj.gameObject);
	}
	//적이 아군을 타격했을 때 호출되는 함수
	public bool Suffer()
	{
		if (Hp < 1)
			return true;

		DamageStack += 1;
		Hp -= 1;
		return false;
	}
	
	public void Die()
	{
		//StartCoroutine("DieEvent");
	}
	//아군 정보를 받아오기위한
	public virtual Friendly GetFriend()
	{
		return this;
	}
	//애니메이션 Hit -> Hit함수 호출
	public virtual void Hit() { }
	public virtual void HitEnd() { }
	
}
