﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FriendlyGuard : Friendly {

	private void Start()
	{
		FriendType = FRIEND_TYPE.Graud;
		StopDistance = 1;
	}
	private void FixedUpdate()
	{
		//DestCheck();
	}
	public override Friendly GetFriend()
	{
		return this;
	}
	public override void Hit()
	{

	}
	public override void HitEnd()
	{

	}
	private IEnumerator AttackEnemy()
	{
		//그룹 중 파티원이 있으면
		while (targetEnemyGroup.FindEnemy() != null)
		{
			setState = FriendlyState.Attack;
			targetEnemy = targetEnemyGroup.FindEnemy();
			//타겟이 죽지 않으면
			while (targetEnemy != null)
			{
				if (isHit)
				{
					isHit = false;
					if (targetEnemy.Hp <1)
					{
						targetEnemy.Die();
						targetEnemy = null;
						setState = FriendlyState.Idle;
					}
					else
					{
						GameManager.ParticleGenerate(targetEnemy.NavObj.position);
					}
				}
				yield return null;
			}
			yield return null;
		}

		targetEnemyGroup = null;
	}
	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("Enemy"))
		{
			if (targetEnemyGroup == null)
			{
				targetEnemy = other.GetComponent<Enemy>();
				targetEnemyGroup = targetEnemy.GroupConductor;
				GroupConductor.GroupCall(targetEnemy);
				StartCoroutine("AttackEnemy");
			}
		}
	}
}
