﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyGroup : MonoBehaviour {

	public int GroupIndex;
	public int EnemyCount;
	public bool isGenerate;

	private List<Enemy> enemyList = new List<Enemy>();
	private WaitForSeconds genDelay = new WaitForSeconds(0.7f);

	public bool GetActive
	{
		get { return gameObject.activeSelf; }
	}

	private void OnEnable()
	{
		GameManager.EnemyGroupEvent += GetCurrentGroup;
	}
	private void OnDisable()
	{
		GameManager.EnemyGroupEvent -= GetCurrentGroup;
	}
	private EnemyGroup GetCurrentGroup()
	{
		return this;
	}
	private IEnumerator MemberAppear()
	{
		if (EnemyCount <= 0)
			EnemyCount = 3;

		Enemy info = null;

		for (int i = 0; i < EnemyCount; ++i)
		{
			int rand = Random.Range(0, PoolManager.current.GetEnemyCountMax);

			GameObject obj = PoolManager.current.PopEnemy((ENEMY_TYPE)rand);
			obj.SetActive(false);
			yield return genDelay;

			obj.transform.SetParent(null);

			info = obj.GetComponentInChildren<Enemy>();

			info.GroupConductor = this;

			info.Target = GameManager.current.CommandPost;

			obj.SetActive(true);
			enemyList.Add(info);
		}
	}
	
	public void GroupMemberInit()
	{
		StartCoroutine(MemberAppear());
	}
	//적군이 죽었을 때 List에서 삭제
	public void RemoveEnemy(Enemy enemy)
	{
		enemyList.Remove(enemy);
	}
	public Enemy FindEnemy()
	{
		for(int i =0; i<enemyList.Count; ++i)
		{
			if (enemyList[i].gameObject.activeSelf)
				return enemyList[i];
		}
		return null;
	}
	public void GroupRouteSet(Friendly _friendly)
	{
		if (_friendly.GroupConductor.GetOrderFriendly() != null)
			_friendly = _friendly.GroupConductor.GetOrderFriendly();

		for (int i = 0; i < enemyList.Count; ++i)
		{
			enemyList[i].Target = _friendly.NavObj;
		}
	}


}
