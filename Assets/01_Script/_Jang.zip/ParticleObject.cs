﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleObject : MonoBehaviour {

	ParticleSystem particle;
	private void Awake()
	{
		particle = GetComponent<ParticleSystem>();
	}
	
	private void Update()
	{
		if (particle.isStopped)
		{
			particle.Stop();
			particle.Clear();
			PoolManager.current.PushParticle(gameObject);
		}
	}
}
