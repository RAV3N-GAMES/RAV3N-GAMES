﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyFlyTeen : Enemy
{
	private void FixedUpdate()
	{
		if (GetTargetFriendly())
		{
			if (DestMove())
			{
				FriendAttack();
			}
		}
		else
		{
			monsterAI.SetDestination(Target.position);
		}
	}

	private void OnTriggerStay(Collider other)
	{
		if (other.CompareTag("Friendly"))
		{
			if (targetFriendGroup == null)
			{
				//우선순위 중에 해당되는 타겟이 없다면 리턴
				targetFriend = other.GetComponent<Friendly>();
				targetFriendGroup = targetFriend.GroupConductor;
			}
		}
	}
}
