﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySinger : Enemy {

	private void Start()
	{
		EnemyType = ENEMY_TYPE.Singer;
	}
	private void FixedUpdate()
	{
	}
	IEnumerator AggroEvent()
	{
		
	yield return null;
		
	}
	private void OnTriggerStay(Collider other)
	{
		if (other.CompareTag("Enemy"))
		{
			if (targetFriend == null)
			{
				//우선순위 중에 해당되는 타겟이 없다면 리턴
				targetFriend = other.GetComponent<Friendly>();
				StartCoroutine("AggroEvent");
			}
		}
	}
}
