﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public enum EnemyState
{
	Idle,
	Walk,
	Attack,
	Hit,
}

public class Enemy : MonoBehaviour {

	public EnemyGroup GroupConductor;

	protected delegate void FindTarget();
	protected FindTarget currentEvent;
	protected NavMeshAgent monsterAI;
	protected Animator anime;
	protected Rigidbody rigidy;
	protected SphereCollider collider;

	protected EnemyState currentState;
	protected EnemyState setState;

	protected Vector3 dest;
	protected Vector3 start;

	public ENEMY_TYPE EnemyType;
	public Transform NavObj;
	public Transform Target;

	public int Hp;
	public int Attack;

	public float Speed;
	public float stopDis;

	public bool isHit;
	public float Distance;
	public float StopDistance;


	public Friendly targetFriend = null;
	public FriendlyGroup targetFriendGroup = null;
	 

	private void Awake()
	{
		monsterAI = GetComponentInParent<NavMeshAgent>();
		collider = GetComponent<SphereCollider>();
		NavObj = monsterAI.transform;
		anime = GetComponent<Animator>();
		rigidy = GetComponent<Rigidbody>();
		
	}
	private void OnEnable()
	{
		collider.enabled = true;
		monsterAI.enabled = true;
		monsterAI.speed = Speed;
		setState = EnemyState.Walk;
		Hp = 5;
		StartCoroutine(AnimEvent());
	}
	protected bool GetTargetFriendly()
	{
		if (targetFriend == null)
		{
			if (targetFriendGroup == null)
			{
				return false;
			}
			else if (targetFriendGroup != null)
			{
				if (targetFriendGroup.GetOrderFriendly() != null)
				{
					targetFriend = targetFriendGroup.GetOrderFriendly();
					return true;
				}
				else
				{
					if (targetFriendGroup != null)
						targetFriendGroup = null;


					return false;
				}
			}
			return false;
		}
		else
			return true;
		
	}
	protected bool DestMove()
	{
		dest = new Vector3(targetFriend.NavObj.position.x, 0, targetFriend.NavObj.position.z);
		start = new Vector3(NavObj.position.x, 0, NavObj.position.z);

		Distance = Vector3.Distance(dest, start);

		if (Distance <= StopDistance)
		{
			if (monsterAI.enabled != false)
			{
				setState = EnemyState.Attack;
				monsterAI.enabled = false;
				return true;
			}
		}
		else
		{
			if (monsterAI.enabled != true)
			{
				if (NavObj.position.x > targetFriend.NavObj.position.x)
					transform.localScale = new Vector3(1, 1, 1);
				else
					transform.localScale = new Vector3(-1, 1, 1);

				setState = EnemyState.Walk;
				monsterAI.enabled = true;
				monsterAI.SetDestination(targetFriend.NavObj.position);
				return false;
			}
		}
		return false;
	}
	protected void FriendAttack()
	{
		if (isHit)
		{
			isHit = false;
			if (targetFriend.Hp < 1)
			{
				targetFriend.Die();
				targetFriend = null;
			}
			else if (targetFriend.Hp > 0)
			{
				GameManager.ParticleGenerate(targetFriend.NavObj.position);
			}
		}
	}
	
	//애니메이션 
	protected IEnumerator AnimEvent()
	{
		while (gameObject.activeSelf)
		{
			if (currentState != setState)
			{
				currentState = setState;
				anime.SetInteger("Action", (int)currentState);
				yield return null;
			}
			else
				yield return new WaitForEndOfFrame();
		}
	}

	private IEnumerator DieEvent()
	{
		anime.SetInteger("Action", 0);
		anime.SetTrigger("Die");

		collider.enabled = false;
		monsterAI.enabled = false;

		GroupConductor.RemoveEnemy(this);

		yield return new WaitForSeconds(1.0f);
		PoolManager.current.PushEnemy(NavObj.gameObject);
	}
	public virtual void HitEnd() { }
	public void Hit()
	{
		isHit = true;
	}
	public void Die()
	{
		StartCoroutine(DieEvent());
	}
}
