﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMafia : Enemy {

	private void Start()
	{
		EnemyType = ENEMY_TYPE.Mafia;
	}
	private void FixedUpdate()
	{
		if (GetTargetFriendly())
		{
			if (DestMove())
			{
				FriendAttack();
			}
		}
		else
		{
			if (!monsterAI.enabled)
				monsterAI.enabled = true;
			monsterAI.SetDestination(Target.position);
		}
	}
	private void OnTriggerStay(Collider other)
	{
		if(other.CompareTag("Friendly"))
		{
			if (targetFriendGroup == null)
			{ 
				targetFriend = other.GetComponent<Friendly>();
				targetFriendGroup = targetFriend.GroupConductor;
			}
		}
	}
}
