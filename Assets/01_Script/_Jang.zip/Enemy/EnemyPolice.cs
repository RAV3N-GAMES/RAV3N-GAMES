﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyPolice : Enemy {

	private void Start()
	{
		EnemyType = ENEMY_TYPE.Police;
	}
	private void FixedUpdate()
	{
		if (GetTargetFriendly())
		{
			if (DestMove())
			{
				FriendAttack();
			}
		}
		else
		{
			monsterAI.SetDestination(GameManager.current.CommandPost.position);
		}

	}

	private void OnTriggerStay(Collider other)
	{
		if (other.CompareTag("Friendly"))
		{
			if (targetFriendGroup == null)
			{
				targetFriend = other.GetComponent<Friendly>();
				targetFriendGroup = targetFriend.GroupConductor;
			}
		}
	}
}
